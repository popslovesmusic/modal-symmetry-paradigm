box\_calculus/  
  tier\_00\_meta\_structure/  
    tier\_00\_metadata.json5  
    tier\_00\_operator\_pack.json5  
    tier\_00\_interaction\_table.json5  
    tier\_00\_axiom\_box.json5  
    tier\_00\_rewrite\_system.json5  
    tier\_00\_module\_pack.json5  
    tier\_00\_test\_suite.json5

  tier\_01\_deviation\_core/  
    tier\_01\_metadata.json5  
    tier\_01\_operator\_pack.json5  
    tier\_01\_interaction\_table.json5  
    tier\_01\_axiom\_box.json5  
    tier\_01\_rewrite\_system.json5  
    tier\_01\_module\_pack.json5  
    tier\_01\_test\_suite.json5

  tier\_02\_modality/  
    tier\_02\_metadata.json5  
    tier\_02\_operator\_pack.json5  
    tier\_02\_interaction\_table.json5  
    tier\_02\_axiom\_box.json5  
    tier\_02\_rewrite\_system.json5  
    tier\_02\_module\_pack.json5  
    tier\_02\_test\_suite.json5

  tier\_03\_higher\_deviation/  
    tier\_03\_metadata.json5  
    tier\_03\_operator\_pack.json5  
    tier\_03\_interaction\_table.json5  
    tier\_03\_axiom\_box.json5  
    tier\_03\_rewrite\_system.json5  
    tier\_03\_module\_pack.json5  
    tier\_03\_test\_suite.json5

  tier\_04\_phi\_projection/  
    tier\_04\_metadata.json5  
    tier\_04\_operator\_pack.json5  
    tier\_04\_interaction\_table.json5  
    tier\_04\_axiom\_box.json5  
    tier\_04\_rewrite\_system.json5  
    tier\_04\_module\_pack.json5  
    tier\_04\_test\_suite.json5

  tier\_05\_pi\_evaluation/  
    tier\_05\_metadata.json5  
    tier\_05\_operator\_pack.json5  
    tier\_05\_interaction\_table.json5  
    tier\_05\_axiom\_box.json5  
    tier\_05\_rewrite\_system.json5  
    tier\_05\_module\_pack.json5  
    tier\_05\_test\_suite.json5

  tier\_06\_mu\_local\_weight/  
    tier\_06\_metadata.json5  
    tier\_06\_operator\_pack.json5  
    tier\_06\_interaction\_table.json5  
    tier\_06\_axiom\_box.json5  
    tier\_06\_rewrite\_system.json5  
    tier\_06\_module\_pack.json5  
    tier\_06\_test\_suite.json5

  tier\_07\_lambda\_curvature/  
    tier\_07\_metadata.json5  
    tier\_07\_operator\_pack.json5  
    tier\_07\_interaction\_table.json5  
    tier\_07\_axiom\_box.json5  
    tier\_07\_rewrite\_system.json5  
    tier\_07\_module\_pack.json5  
    tier\_07\_test\_suite.json5

  tier\_08\_psi\_wave/  
    tier\_08\_metadata.json5  
    tier\_08\_operator\_pack.json5  
    tier\_08\_interaction\_table.json5  
    tier\_08\_axiom\_box.json5  
    tier\_08\_rewrite\_system.json5  
    tier\_08\_module\_pack.json5  
    tier\_08\_test\_suite.json5

  tier\_09\_sigma\_summation/  
    tier\_09\_metadata.json5  
    tier\_09\_operator\_pack.json5  
    tier\_09\_interaction\_table.json5  
    tier\_09\_axiom\_box.json5  
    tier\_09\_rewrite\_system.json5  
    tier\_09\_module\_pack.json5  
    tier\_09\_test\_suite.json5

  tier\_10\_theta\_polarity\_logic/  
    tier\_10\_metadata.json5  
    tier\_10\_operator\_pack.json5  
    tier\_10\_interaction\_table.json5  
    tier\_10\_axiom\_box.json5  
    tier\_10\_rewrite\_system.json5  
    tier\_10\_module\_pack.json5  
    tier\_10\_test\_suite.json5

  tier\_11\_chi\_evolution/  
    tier\_11\_metadata.json5  
    tier\_11\_operator\_pack.json5  
    tier\_11\_interaction\_table.json5  
    tier\_11\_axiom\_box.json5  
    tier\_11\_rewrite\_system.json5  
    tier\_11\_module\_pack.json5  
    tier\_11\_test\_suite.json5

  tier\_12\_omega\_constraints/  
    tier\_12\_metadata.json5  
    tier\_12\_operator\_pack.json5  
    tier\_12\_interaction\_table.json5  
    tier\_12\_axiom\_box.json5  
    tier\_12\_rewrite\_system.json5  
    tier\_12\_module\_pack.json5  
    tier\_12\_test\_suite.json5

  tier\_13\_rho\_federation/  
    tier\_13\_metadata.json5  
    tier\_13\_operator\_pack.json5  
    tier\_13\_interaction\_table.json5  
    tier\_13\_axiom\_box.json5  
    tier\_13\_rewrite\_system.json5  
    tier\_13\_module\_pack.json5  
    tier\_13\_test\_suite.json5

